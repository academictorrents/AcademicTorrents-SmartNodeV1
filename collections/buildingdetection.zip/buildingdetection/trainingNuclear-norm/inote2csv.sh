cat $1  | grep -A 2 "<point" | grep "<c>" | sed 's/<c><x n="//g' | sed 's/"\/><y n="/,/g' | sed 's/"\/><\/c>/,/g'
